#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFile>
#include<QStandardItemModel>
#include<QTextStream>
#include<QVector>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    mModel = new QStandardItemModel(this);
    ui->tableView->setModel(mModel);
   abrirArchivo();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::abrirArchivo(){
    QFile movieData("/home/jonathan/Escritorio/movie_metadata.csv");
    if(!movieData.open(QIODevice::ReadOnly | QIODevice::Text)){
        return;
    }
    QTextStream xin(&movieData);
    int ix=0;
    while(!xin.atEnd()){
        mModel->setRowCount(ix);
        auto line = xin.readLine();
        auto values = line.split(",");
        const int colCount = values.size();
        mModel->setColumnCount(colCount);
        for(int jx = 0; jx<colCount;jx++){
            setValueAt(ix,jx,values.at(jx));
        }
        ix++;
    }
    movieData.close();
}
void MainWindow::setValueAt(int ix, int jx, const QString &value){
    if(!mModel->item(ix,jx)){
        mModel->setItem(ix,jx, new QStandardItem(value));
    }else{
        mModel->item(ix,jx)->setText(value);
    }
}
