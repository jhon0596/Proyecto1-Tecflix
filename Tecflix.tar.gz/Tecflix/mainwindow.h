#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QStandardItemModel>
namespace Ui {
class MainWindow;
}
class QStandardItemModel;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void abrirArchivo();
    ~MainWindow();

private:
    void setValueAt(int ix, int jx, const QString &value);
    Ui::MainWindow *ui;
    QStandardItemModel *mModel;
};

#endif // MAINWINDOW_H
